#! /bin/bash
# bash delete_all.sh
#cd /home/pi/Desktop/karli/ 
sqlite3 -line /usr/src/CalypsoBTS/hlr.sqlite3 'delete from subscriber;'
