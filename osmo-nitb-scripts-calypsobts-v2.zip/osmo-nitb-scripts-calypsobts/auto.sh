#!/bin/sh 
sudo gnome-terminal --geometry=75x20 -- ./trx.sh
sudo gnome-terminal --geometry=75x20 -- ./trx2.sh
#sudo gnome-terminal --geometry=600x15 -- sudo python3 main.py -u 
#sudo gnome-terminal --geometry=600x15 -- ./LSMS.sh 
#read e
