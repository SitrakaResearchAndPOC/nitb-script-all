#!/bin/sh
cp services/osmo-nitb3.service /lib/systemd/system
cp services/osmo-bts-trx3.service /lib/systemd/system
cp services/osmo-trx-lms3.service /lib/systemd/system
#cp services/osmo-pcu3.service /lib/systemd/system
#cp services/osmo-sgsn3.service /lib/systemd/system
#cp services/osmo-ggsn3.service /lib/systemd/system
#cp services/osmo-sip-connector3.service /lib/systemd/system

systemctl daemon-reload
